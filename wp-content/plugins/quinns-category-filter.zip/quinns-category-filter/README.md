# wp-category-filter
WP Category filter (coding challange)
